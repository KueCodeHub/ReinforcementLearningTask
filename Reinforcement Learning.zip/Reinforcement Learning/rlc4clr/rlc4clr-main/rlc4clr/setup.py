from setuptools import setup

setup(name='clr_envs',
      version='0.0.1',
      install_requires=['gymnasium==0.28.1']
)
