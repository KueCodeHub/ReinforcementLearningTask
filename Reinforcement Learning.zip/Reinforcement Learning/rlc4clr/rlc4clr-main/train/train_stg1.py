import os
import gym
import ray
from ray import air, tune
from ray.rllib.utils.framework import try_import_tf, try_import_torch
from ray.rllib.utils.test_utils import check_learning_achieved
from ray.tune.registry import get_trainable_cls, register_env

# Mock Custom Environment
class LoadRestorationEnv(gym.Env):
    def __init__(self, config=None):
        super(LoadRestorationEnv, self).__init__()
        # Define observation space: 10 continuous values between 0.0 and 1.0
        self.observation_space = gym.spaces.Box(low=0.0, high=1.0, shape=(10,), dtype=float)
        # Define action space: 2 discrete actions (e.g., ON or OFF)
        self.action_space = gym.spaces.Discrete(2)
        self.state = None

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        # Reset environment to a random state
        self.state = self.observation_space.sample()
        return self.state, {}

    def step(self, action):
        # Reward logic: Reward for action 1, penalty for action 0
        reward = 1.0 if action == 1 else -1.0
        # Terminate after a single step for simplicity (can customize)
        done = False
        # Generate new state
        self.state = self.observation_space.sample()
        return self.state, reward, done, {}

CURRENT_FILE_PATH = os.path.dirname(os.path.abspath(__file__))
LOG_PATH = os.path.join(CURRENT_FILE_PATH, "results/STG1")

tf1, tf, tfv = try_import_tf()
torch, nn = try_import_torch()

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=str, default="PPO", help="RLlib-registered algorithm.")
    parser.add_argument("--framework", choices=["tf", "torch"], default="torch")
    parser.add_argument("--stop-timesteps", type=int, default=10000, help="Stop after this many timesteps.")
    parser.add_argument("--worker-num", type=int, default=1, help="Number of rollout workers.")
    parser.add_argument("--episodes-per-batch", type=int, default=10)
    parser.add_argument("--stepsize", type=float, default=0.01)
    parser.add_argument("--sigma", type=float, default=0.1)
    parser.add_argument("--checkpoint-frequency", type=int, default=10)
    parser.add_argument("--checkpoint-to-save", type=int, default=3)
    parser.add_argument("--local-mode", action="store_true", help="Use local mode for debugging.")
    parser.add_argument("--ip-head", type=str, default=None, help="IP head for Ray cluster.")
    parser.add_argument("--redis-password", type=str, default=None, help="Redis password for Ray cluster.")
    parser.add_argument("--as-test", action="store_true", help="Run as a test with learning checks.")

    args = parser.parse_args()
    print(f"Running with following CLI options: {args}")

    # Initialize Ray
    if args.ip_head is not None:
        ray.init(address=args.ip_head, _redis_password=args.redis_password, local_mode=False)
    else:
        ray.init(local_mode=args.local_mode)

    env_name = "LoadRestorationEnv"

    # Register custom environment
    def env_creator(config):
        return LoadRestorationEnv(config)

    register_env(env_name, env_creator)

    # Define RLlib configuration
    config = (
        get_trainable_cls(args.run)
        .get_default_config()
        .environment(env_name, env_config={})
        .framework(args.framework)
        .rollouts(num_rollout_workers=args.worker_num)
        .training(
            episodes_per_batch=args.episodes_per_batch,
            model={"fcnet_hiddens": [256, 256]},  # Neural network structure
        )
        .resources(num_gpus=int(os.environ.get("RLLIB_NUM_GPUS", "0")))  # Use GPUs if available
    )

    stop = {"timesteps_total": args.stop_timesteps}

    # Automated training using Ray Tune
    print("Training automatically with Ray Tune")
    tuner = tune.Tuner(
        args.run,
        param_space=config.to_dict(),
        run_config=air.RunConfig(
            stop=stop,
            local_dir=LOG_PATH,
            checkpoint_config=air.CheckpointConfig(
                checkpoint_frequency=args.checkpoint_frequency,
                num_to_keep=args.checkpoint_to_save,
                checkpoint_score_attribute="episode_reward_mean",
            ),
        ),
    )
    results = tuner.fit()

    if args.as_test:
        print("Checking if learning goals were achieved")
        check_learning_achieved(results, args.stop_timesteps)

    ray.shutdown()
