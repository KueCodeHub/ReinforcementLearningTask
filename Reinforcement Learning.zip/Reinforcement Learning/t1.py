import numpy as np
import gym
from gym import spaces
import tensorflow as tf
import matplotlib.pyplot as plt
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv

class IEEE123BusLoadRestorationEnv(gym.Env):
    def __init__(self):
        super(IEEE123BusLoadRestorationEnv, self).__init__()

        # Simulation parameters (mocked)
        self.num_buses = 123  # IEEE 123 bus test system
        self.max_load = 1.0   # Max load restoration (normalized)
        
        # State space: Mock state with voltage levels, load restoration, and system health
        self.observation_space = gym.spaces.Box(
            low=np.array([0, 0, 0]),  # Minimum values (e.g., voltage, load restoration, health)
            high=np.array([1, 1, 1]),  # Maximum values (e.g., voltage, load restoration, health)
            dtype=np.float32
        )

        # Action space: Binary action for each critical load section (on/off)
        self.action_space = gym.spaces.MultiDiscrete([2] * 15)  # 15 critical load sections
        
        # Curriculum learning parameters
        self.curriculum_stages = [
            {"difficulty": "basic", "load_constraints": 0.5},
            {"difficulty": "intermediate", "load_constraints": 0.7},
            {"difficulty": "advanced", "load_constraints": 0.9}
        ]
        self.current_stage = 0

        # Initialize state
        self.state = np.zeros(3)  # [voltage, load_restoration, system_health]
        self.steps_taken = 0

    def _apply_load_switching_action(self, action):
        # Mock action: Apply load switching
        # Here we simulate a simple model where turning loads on/off affects system health
        if action.sum() > 0:
            self.state[1] += 0.1  # Increase load restoration progress
        else:
            self.state[1] -= 0.1  # Decrease load restoration progress
        self.state[1] = np.clip(self.state[1], 0, self.max_load)  # Clip load restoration between 0 and max_load

    def _run_power_flow(self):
        # Mock power flow simulation: This would usually interact with OpenDSS or another simulator.
        # For now, we'll simulate voltage stability as a function of load restoration.
        self.state[0] = self.state[1]  # Assume voltage is directly tied to load restoration

        # Randomly affect system health
        self.state[2] = np.random.uniform(0.7, 1.0)  # Simulate system health

    def _compute_reward(self):
        # Reward is based on load restoration and system health
        return 0.6 * self.state[1] + 0.4 * self.state[2]

    def _check_termination(self):
        # Terminate if load restoration is complete
        return self.state[1] >= self.max_load or self.steps_taken >= 100

    def _get_state(self):
        # Return current state
        return self.state

    def reset(self):
        # Reset state to initial values
        self.state = np.zeros(3)
        self.steps_taken = 0
        return self.state

    def render(self, mode='human'):
        # Visualize system status and restoration progress
        print(f"Voltage: {self.state[0]:.2f}, Load Restoration: {self.state[1]:.2f}, System Health: {self.state[2]:.2f}")

    def step(self, action):
        self.steps_taken += 1

        # Apply action and simulate power flow
        self._apply_load_switching_action(action)
        self._run_power_flow()

        # Compute reward and observation
        reward = self._compute_reward()
        observation = self._get_state()

        # Check termination
        done = self._check_termination()

        return observation, reward, done, {}

    def _curriculum_adjust_difficulty(self):
        # Dynamically adjust learning difficulty (mocked)
        if self.current_stage < len(self.curriculum_stages) - 1:
            self.current_stage += 1
        return self.curriculum_stages[self.current_stage]


class LoadRestorationTrainer:
    def __init__(self):
        self.env = IEEE123BusLoadRestorationEnv()
        self.vec_env = DummyVecEnv([lambda: self.env])

    def train(self, total_timesteps=50000):
        model = PPO(
            "MlpPolicy", 
            self.vec_env, 
            verbose=1,
            learning_rate=1e-3
        )
        model.learn(total_timesteps=total_timesteps)
        return model


def plot_training_results(model, env):
    # Evaluate and plot model performance
    episodes = 10
    results = []

    for _ in range(episodes):
        obs = env.reset()
        done = False
        episode_reward = 0

        while not done:
            action, _ = model.predict(obs)
            obs, reward, done, _ = env.step(action)
            episode_reward += reward

        results.append(episode_reward)

    plt.figure(figsize=(10, 5))
    plt.plot(results, label='Episode Rewards')
    plt.title('Load Restoration Performance')
    plt.xlabel('Episodes')
    plt.ylabel('Cumulative Reward')
    plt.legend()
    plt.show()


def main():
    trainer = LoadRestorationTrainer()
    trained_model = trainer.train()
    plot_training_results(trained_model, trainer.env)


if __name__ == "__main__":
    main()
